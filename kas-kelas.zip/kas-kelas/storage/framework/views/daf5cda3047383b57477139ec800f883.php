<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<h3 class="mb-4">Dashboard</h3>
<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card text-bg-success"><div class="card-body">
        <div>Total Pemasukan</div><h4>Rp <?php echo e(number_format($totalMasuk, 0, ',', '.')); ?></h4></div></div></div>
    <div class="col-md-3"><div class="card text-bg-danger"><div class="card-body">
        <div>Total Pengeluaran</div><h4>Rp <?php echo e(number_format($totalKeluar, 0, ',', '.')); ?></h4></div></div></div>
    <div class="col-md-3"><div class="card text-bg-primary"><div class="card-body">
        <div>Saldo Kas</div><h4>Rp <?php echo e(number_format($saldo, 0, ',', '.')); ?></h4></div></div></div>
    <div class="col-md-3"><div class="card text-bg-secondary"><div class="card-body">
        <div>Jumlah Anggota</div><h4><?php echo e($jumlahAnggota); ?></h4></div></div></div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between">
        <strong>5 Transaksi Terbaru</strong>
        <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-sm btn-primary">+ Catat Transaksi</a>
    </div>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead><tr><th>Tanggal</th><th>Anggota</th><th>Jenis</th><th>Jumlah</th><th>Keterangan</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($t->tanggal->format('d/m/Y')); ?></td>
                    <td><?php echo e($t->anggota->nama ?? '-'); ?></td>
                    <td><span class="badge text-bg-<?php echo e($t->jenis == 'masuk' ? 'success' : 'danger'); ?>"><?php echo e(ucfirst($t->jenis)); ?></span></td>
                    <td>Rp <?php echo e(number_format($t->jumlah, 0, ',', '.')); ?></td>
                    <td><?php echo e($t->keterangan); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-muted">Belum ada transaksi.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kas-kelas\resources\views/dashboard.blade.php ENDPATH**/ ?>