<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Kas Kelas'); ?> - Sistem Kas Kelas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-md navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">💰 Kas Kelas</a>
        <div class="navbar-nav">
            <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="nav-link <?php echo e(request()->routeIs('anggota.*') ? 'active' : ''); ?>" href="<?php echo e(route('anggota.index')); ?>">Anggota</a>
            <a class="nav-link <?php echo e(request()->routeIs('transaksi.*') ? 'active' : ''); ?>" href="<?php echo e(route('transaksi.index')); ?>">Transaksi Kas</a>
        </div>
    </div>
</nav>
<main class="container pb-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\kas-kelas\resources\views/layouts/app.blade.php ENDPATH**/ ?>