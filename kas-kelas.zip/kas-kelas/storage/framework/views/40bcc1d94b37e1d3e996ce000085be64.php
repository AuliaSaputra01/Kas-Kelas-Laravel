<?php $__env->startSection('title', 'Anggota'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h3>Data Anggota</h3>
    <a href="<?php echo e(route('anggota.create')); ?>" class="btn btn-primary">+ Tambah Anggota</a>
</div>
<form class="row g-2 mb-3" method="GET">
    <div class="col-md-4"><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama / NPM"></div>
    <div class="col-auto"><button class="btn btn-outline-secondary">Cari</button></div>
</form>
<div class="card"><div class="table-responsive">
    <table class="table table-hover mb-0">
        <thead><tr><th>#</th><th>NPM</th><th>Nama</th><th>No. HP</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($anggotas->firstItem() + $loop->index); ?></td>
                <td><?php echo e($a->npm); ?></td><td><?php echo e($a->nama); ?></td><td><?php echo e($a->no_hp ?? '-'); ?></td>
                <td class="text-end">
                    <a href="<?php echo e(route('anggota.edit', $a)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('anggota.destroy', $a)); ?>" method="POST" class="d-inline"
                          onsubmit="return confirm('Hapus anggota ini?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-muted">Data tidak ditemukan.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div></div>
<div class="mt-3"><?php echo e($anggotas->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kas-kelas\resources\views/anggota/index.blade.php ENDPATH**/ ?>