<?php $__env->startSection('title', 'Transaksi Kas'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h3>Transaksi Kas</h3>
    <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-primary">+ Catat Transaksi</a>
</div>
<form class="row g-2 mb-3" method="GET">
    <div class="col-md-3">
        <select name="jenis" class="form-select">
            <option value="">Semua jenis</option>
            <option value="masuk" <?php if(request('jenis') == 'masuk'): echo 'selected'; endif; ?>>Pemasukan</option>
            <option value="keluar" <?php if(request('jenis') == 'keluar'): echo 'selected'; endif; ?>>Pengeluaran</option>
        </select>
    </div>
    <div class="col-md-4"><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari keterangan"></div>
    <div class="col-auto"><button class="btn btn-outline-secondary">Filter</button></div>
</form>
<div class="card"><div class="table-responsive">
    <table class="table table-hover mb-0">
        <thead><tr><th>Tanggal</th><th>Anggota</th><th>Jenis</th><th>Jumlah</th><th>Keterangan</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($t->tanggal->format('d/m/Y')); ?></td>
                <td><?php echo e($t->anggota->nama ?? '-'); ?></td>
                <td><span class="badge text-bg-<?php echo e($t->jenis == 'masuk' ? 'success' : 'danger'); ?>"><?php echo e(ucfirst($t->jenis)); ?></span></td>
                <td>Rp <?php echo e(number_format($t->jumlah, 0, ',', '.')); ?></td>
                <td><?php echo e($t->keterangan); ?></td>
                <td class="text-end">
                    <a href="<?php echo e(route('transaksi.edit', $t)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('transaksi.destroy', $t)); ?>" method="POST" class="d-inline"
                          onsubmit="return confirm('Hapus transaksi ini?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center text-muted">Belum ada transaksi.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div></div>
<div class="mt-3"><?php echo e($transaksis->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\kas-kelas\resources\views/transaksi/index.blade.php ENDPATH**/ ?>